function food(){
    document.getElementById('pc').src="img1.jpg";
}
function drink(){
    document.getElementById('pc').src="img2.jpg";
}
function menu(){
    document.getElementById('pc').src="img3.jpg";
}
